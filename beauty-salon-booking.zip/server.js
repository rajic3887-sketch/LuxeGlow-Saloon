const express = require('express');
const path = require('path');
const cors = require('cors');
const config = require('./config');
const db = require('./database/db');

// Route Imports
const authRoutes = require('./routes/auth');
const servicesRoutes = require('./routes/services');
const stylistsRoutes = require('./routes/stylists');
const appointmentsRoutes = require('./routes/appointments');
const adminRoutes = require('./routes/admin');
const contactRoutes = require('./routes/contact');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Simple request logger
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (req.originalUrl.startsWith('/api')) {
      console.log(`[${req.method}] ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/stylists', stylistsRoutes);
app.use('/api/appointments', appointmentsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/contact', contactRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    salon: 'LuxeGlow Beauty & Spa'
  });
});

// Fallback route for SPA or unmatched paths
app.get('*', (req, res) => {
  // If request doesn't match API and doesn't have an extension, try matching HTML or send index
  if (!req.path.startsWith('/api')) {
    const possibleFile = path.join(__dirname, 'public', `${req.path}.html`);
    res.sendFile(possibleFile, (err) => {
      if (err) {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
      }
    });
  } else {
    res.status(404).json({ success: false, message: 'API route not found' });
  }
});

// Start Server & Initialize Database
const startServer = async () => {
  try {
    await db.initDB();
    const server = app.listen(config.PORT, () => {
      console.log('====================================================');
      console.log('  ✨ LuxeGlow Beauty Salon Booking Portal Online ✨  ');
      console.log(`  Local URL: http://localhost:${config.PORT}`);
      console.log('  Admin Portal: http://localhost:' + config.PORT + '/admin.html');
      console.log('  Customer Demo: customer@gmail.com / customer123');
      console.log('  Admin Demo:    admin@luxeglow.com / admin123');
      console.log('====================================================');
    });

    // Graceful shutdown
    process.on('SIGINT', () => {
      console.log('\nShutting down server gracefully...');
      server.close(() => {
        db.db.close(() => {
          console.log('SQLite database connection closed.');
          process.exit(0);
        });
      });
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
