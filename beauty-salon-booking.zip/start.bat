@echo off
title LuxeGlow Beauty Salon Appointment Portal
echo ===================================================
echo     LuxeGlow Beauty Salon Appointment System       
echo ===================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking Node.js installation...
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found on your system PATH!
    echo Please install Node.js (LTS version) from: https://nodejs.org/
    echo Then re-run this script or run 'npm start' in VS Code terminal.
    echo.
    pause
    exit /b 1
)

echo [2/3] Checking and installing dependencies...
if not exist "node_modules\" (
    echo Installing npm packages...
    call npm install
) else (
    echo Dependencies already installed.
)

echo.
echo [3/3] Starting LuxeGlow Salon server...
echo ---------------------------------------------------
echo Server will run at: http://localhost:3000
echo Admin Portal at:    http://localhost:3000/admin.html
echo Customer Login:     customer@gmail.com / customer123
echo Admin Login:        admin@luxeglow.com / admin123
echo ---------------------------------------------------
echo.

call npm start
pause
