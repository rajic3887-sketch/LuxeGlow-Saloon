const path = require('path');
require('dotenv').config();

module.exports = {
  PORT: process.env.PORT || 3000,
  JWT_SECRET: process.env.JWT_SECRET || 'luxeglow_beauty_salon_secret_key_default',
  DB_PATH: process.env.DB_PATH || path.join(__dirname, 'database', 'salon.sqlite')
};
