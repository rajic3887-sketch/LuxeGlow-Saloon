const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const ALL_TIME_SLOTS = [
  '09:00 AM',
  '10:00 AM',
  '11:00 AM',
  '12:00 PM',
  '01:00 PM',
  '02:00 PM',
  '03:00 PM',
  '04:00 PM',
  '05:00 PM',
  '06:00 PM'
];

// GET /api/appointments/availability?date=YYYY-MM-DD&stylist_id=X
router.get('/availability', async (req, res) => {
  try {
    const { date, stylist_id } = req.query;

    if (!date) {
      return res.status(400).json({ success: false, message: 'Date parameter is required.' });
    }

    let query = `
      SELECT appointment_time 
      FROM appointments 
      WHERE appointment_date = ? 
        AND status != 'cancelled'
    `;
    const params = [date];

    if (stylist_id && stylist_id !== 'any') {
      query += ` AND stylist_id = ?`;
      params.push(stylist_id);
    }

    const bookedRows = await db.all(query, params);
    const bookedSlots = bookedRows.map(r => r.appointment_time);

    const slots = ALL_TIME_SLOTS.map(time => ({
      time,
      available: !bookedSlots.includes(time)
    }));

    res.json({
      success: true,
      date,
      stylist_id: stylist_id || 'any',
      slots
    });
  } catch (error) {
    console.error('Error checking availability:', error);
    res.status(500).json({ success: false, message: 'Failed to check appointment availability.' });
  }
});

// POST /api/appointments (Book appointment - Requires Auth)
router.post('/', requireAuth, async (req, res) => {
  try {
    const { service_id, stylist_id, appointment_date, appointment_time, customer_notes } = req.body;
    const user_id = req.user.id;

    if (!service_id || !appointment_date || !appointment_time) {
      return res.status(400).json({
        success: false,
        message: 'Please provide service, appointment date, and time slot.'
      });
    }

    // Verify service exists and get price
    const service = await db.get('SELECT * FROM services WHERE id = ?', [service_id]);
    if (!service) {
      return res.status(404).json({ success: false, message: 'Selected service does not exist.' });
    }

    // Check collision for the same stylist, date and time
    let assignedStylistId = stylist_id ? parseInt(stylist_id) : null;
    if (assignedStylistId) {
      const collision = await db.get(
        `SELECT id FROM appointments 
         WHERE stylist_id = ? 
           AND appointment_date = ? 
           AND appointment_time = ? 
           AND status != 'cancelled'`,
        [assignedStylistId, appointment_date, appointment_time]
      );

      if (collision) {
        return res.status(400).json({
          success: false,
          message: 'The selected stylist is already booked for this time slot. Please choose another slot or stylist.'
        });
      }
    } else {
      // If "any stylist" selected, pick the first available active stylist who is free at this slot
      const allStylists = await db.all('SELECT id FROM stylists WHERE is_active = 1');
      for (const s of allStylists) {
        const busy = await db.get(
          `SELECT id FROM appointments 
           WHERE stylist_id = ? 
             AND appointment_date = ? 
             AND appointment_time = ? 
             AND status != 'cancelled'`,
          [s.id, appointment_date, appointment_time]
        );
        if (!busy) {
          assignedStylistId = s.id;
          break;
        }
      }
    }

    const result = await db.run(
      `INSERT INTO appointments 
       (user_id, service_id, stylist_id, appointment_date, appointment_time, status, total_price, customer_notes)
       VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`,
      [
        user_id,
        service.id,
        assignedStylistId,
        appointment_date,
        appointment_time,
        service.price,
        customer_notes || ''
      ]
    );

    // Fetch newly created appointment with details
    const newAppointment = await db.get(
      `SELECT a.*, 
              s.name AS service_name, s.duration AS service_duration,
              st.name AS stylist_name,
              u.name AS customer_name, u.email AS customer_email, u.phone AS customer_phone
       FROM appointments a
       JOIN services s ON a.service_id = s.id
       LEFT JOIN stylists st ON a.stylist_id = st.id
       JOIN users u ON a.user_id = u.id
       WHERE a.id = ?`,
      [result.lastID]
    );

    res.status(201).json({
      success: true,
      message: 'Appointment booked successfully!',
      appointment: newAppointment
    });
  } catch (error) {
    console.error('Error creating appointment:', error);
    res.status(500).json({ success: false, message: 'Failed to complete appointment booking.' });
  }
});

// GET /api/appointments/my (Get current customer's appointments)
router.get('/my', requireAuth, async (req, res) => {
  try {
    const user_id = req.user.id;
    const appointments = await db.all(
      `SELECT a.*, 
              s.name AS service_name, s.duration AS service_duration, s.image_url AS service_image,
              st.name AS stylist_name, st.title AS stylist_title
       FROM appointments a
       JOIN services s ON a.service_id = s.id
       LEFT JOIN stylists st ON a.stylist_id = st.id
       WHERE a.user_id = ?
       ORDER BY a.appointment_date DESC, a.appointment_time DESC`,
      [user_id]
    );

    res.json({ success: true, appointments });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to retrieve appointments.' });
  }
});

// GET /api/appointments (Admin only - get all appointments)
router.get('/', requireAdmin, async (req, res) => {
  try {
    const { status, date, search } = req.query;
    let query = `
      SELECT a.*, 
             s.name AS service_name, s.duration AS service_duration,
             st.name AS stylist_name,
             u.name AS customer_name, u.email AS customer_email, u.phone AS customer_phone
      FROM appointments a
      JOIN services s ON a.service_id = s.id
      LEFT JOIN stylists st ON a.stylist_id = st.id
      JOIN users u ON a.user_id = u.id
      WHERE 1=1
    `;
    const params = [];

    if (status && status !== 'all') {
      query += ` AND a.status = ?`;
      params.push(status);
    }

    if (date) {
      query += ` AND a.appointment_date = ?`;
      params.push(date);
    }

    if (search) {
      query += ` AND (u.name LIKE ? OR u.email LIKE ? OR s.name LIKE ? OR st.name LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    query += ` ORDER BY a.appointment_date DESC, a.appointment_time ASC`;

    const appointments = await db.all(query, params);
    res.json({ success: true, appointments });
  } catch (error) {
    console.error('Admin appointments error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch appointments.' });
  }
});

// PUT /api/appointments/:id/cancel (Customer can cancel their own, or Admin)
router.put('/:id/cancel', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const appointment = await db.get('SELECT * FROM appointments WHERE id = ?', [id]);

    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    // Only owner or admin can cancel
    if (appointment.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this appointment.' });
    }

    if (appointment.status === 'completed') {
      return res.status(400).json({ success: false, message: 'Cannot cancel an appointment that is already completed.' });
    }

    await db.run(
      `UPDATE appointments SET status = 'cancelled' WHERE id = ?`,
      [id]
    );

    res.json({ success: true, message: 'Appointment cancelled successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to cancel appointment.' });
  }
});

// PUT /api/appointments/:id/status (Admin updates status)
router.put('/:id/status', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, admin_notes } = req.body;

    const validStatuses = ['pending', 'confirmed', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid appointment status.' });
    }

    const appointment = await db.get('SELECT id FROM appointments WHERE id = ?', [id]);
    if (!appointment) {
      return res.status(404).json({ success: false, message: 'Appointment not found.' });
    }

    await db.run(
      `UPDATE appointments 
       SET status = ?, admin_notes = COALESCE(?, admin_notes)
       WHERE id = ?`,
      [status, admin_notes !== undefined ? admin_notes : null, id]
    );

    res.json({ success: true, message: `Appointment status updated to ${status}.` });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update appointment status.' });
  }
});

// DELETE /api/appointments/:id (Admin delete)
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await db.run('DELETE FROM appointments WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Appointment record deleted successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to delete appointment.' });
  }
});

module.exports = router;
