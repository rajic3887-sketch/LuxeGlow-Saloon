// LuxeGlow Beauty Salon - Booking Flow Manager

let bookingState = {
  serviceId: null,
  serviceName: '',
  servicePrice: 0,
  serviceDuration: 0,
  stylistId: 'any',
  stylistName: 'Any Available Specialist',
  date: '',
  time: '',
  notes: ''
};

let currentStep = 1;
let servicesList = [];
let stylistsList = [];

document.addEventListener('DOMContentLoaded', async () => {
  // Check if there is temporary state in sessionStorage (e.g. after login redirect)
  const savedState = sessionStorage.getItem('temp_booking_state');
  if (savedState) {
    try {
      bookingState = JSON.parse(savedState);
      sessionStorage.removeItem('temp_booking_state');
    } catch (e) {}
  }

  // Set default minimum date for datepicker to today
  const dateInput = document.getElementById('booking-date');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
    if (!bookingState.date) {
      dateInput.value = today;
      bookingState.date = today;
    } else {
      dateInput.value = bookingState.date;
    }

    dateInput.addEventListener('change', (e) => {
      bookingState.date = e.target.value;
      loadAvailableSlots();
      updateSummaryCard();
    });
  }

  // Load Services & Stylists
  await loadBookingServices();
  await loadBookingStylists();

  // Check URL query parameters for pre-selected service
  const urlParams = new URLSearchParams(window.location.search);
  const paramServiceId = urlParams.get('serviceId');
  if (paramServiceId) {
    selectService(parseInt(paramServiceId));
  } else if (bookingState.serviceId) {
    selectService(bookingState.serviceId);
  }

  // Initial slot load
  if (bookingState.date) {
    loadAvailableSlots();
  }

  updateSummaryCard();
});

// Load services into Step 1 list
async function loadBookingServices() {
  const container = document.getElementById('service-select-container');
  if (!container) return;

  try {
    const res = await fetch('/api/services');
    const data = await res.json();
    if (data.success && data.services) {
      servicesList = data.services;
      container.innerHTML = servicesList.map(s => `
        <div class="service-select-item ${bookingState.serviceId === s.id ? 'selected' : ''}" 
             id="service-opt-${s.id}" 
             onclick="selectService(${s.id})">
          <div class="service-item-info">
            <h4>${s.name}</h4>
            <p>${s.description ? s.description.substring(0, 75) + '...' : ''}</p>
          </div>
          <div class="service-item-meta">
            <div class="service-item-price">${formatCurrency(s.price)}</div>
            <div class="service-item-duration">${s.duration} mins</div>
          </div>
        </div>
      `).join('');
    }
  } catch (err) {
    container.innerHTML = '<p style="color: var(--danger);">Failed to load salon services.</p>';
  }
}

// Select a service
function selectService(id) {
  const service = servicesList.find(s => s.id === id);
  if (!service) return;

  bookingState.serviceId = service.id;
  bookingState.serviceName = service.name;
  bookingState.servicePrice = service.price;
  bookingState.serviceDuration = service.duration;

  // Highlight selected card
  document.querySelectorAll('.service-select-item').forEach(el => el.classList.remove('selected'));
  const activeEl = document.getElementById(`service-opt-${id}`);
  if (activeEl) activeEl.classList.add('selected');

  updateSummaryCard();
}

// Load stylists into Step 2 grid
async function loadBookingStylists() {
  const container = document.getElementById('stylist-select-container');
  if (!container) return;

  try {
    const res = await fetch('/api/stylists');
    const data = await res.json();

    if (data.success && data.stylists) {
      stylistsList = data.stylists;

      let html = `
        <div class="stylist-select-card ${bookingState.stylistId === 'any' ? 'selected' : ''}" 
             id="stylist-opt-any" 
             onclick="selectStylist('any', 'Any Available Specialist')">
          <div style="width: 70px; height: 70px; border-radius: 50%; background: var(--primary-light); color: var(--primary-dark); display: flex; align-items: center; justify-content: center; font-size: 24px; margin: 0 auto 12px;">★</div>
          <div class="name">First Available</div>
          <div class="role">Maximum Flexibility</div>
        </div>
      `;

      html += stylistsList.map(st => `
        <div class="stylist-select-card ${bookingState.stylistId == st.id ? 'selected' : ''}" 
             id="stylist-opt-${st.id}" 
             onclick="selectStylist(${st.id}, '${st.name}')">
          <img src="${st.image_url}" alt="${st.name}">
          <div class="name">${st.name}</div>
          <div class="role">${st.title}</div>
        </div>
      `).join('');

      container.innerHTML = html;
    }
  } catch (err) {
    container.innerHTML = '<p style="color: var(--danger);">Failed to load specialists.</p>';
  }
}

// Select a stylist
function selectStylist(id, name) {
  bookingState.stylistId = id;
  bookingState.stylistName = name;

  document.querySelectorAll('.stylist-select-card').forEach(el => el.classList.remove('selected'));
  const activeEl = document.getElementById(`stylist-opt-${id}`);
  if (activeEl) activeEl.classList.add('selected');

  loadAvailableSlots();
  updateSummaryCard();
}

// Fetch availability time slots from backend
async function loadAvailableSlots() {
  const container = document.getElementById('slots-container');
  if (!container) return;

  const date = bookingState.date || document.getElementById('booking-date').value;
  if (!date) return;

  container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; color: var(--text-muted); font-size: 14px;">Checking available salon slots...</div>';

  try {
    const stylistParam = bookingState.stylistId || 'any';
    const res = await fetch(`/api/appointments/availability?date=${date}&stylist_id=${stylistParam}`);
    const data = await res.json();

    if (data.success && data.slots) {
      container.innerHTML = data.slots.map(slot => `
        <button type="button" 
                class="time-slot-btn ${slot.available ? '' : 'booked'} ${bookingState.time === slot.time && slot.available ? 'selected' : ''}"
                ${slot.available ? `onclick="selectTimeSlot('${slot.time}')"` : 'disabled'}
                title="${slot.available ? 'Available' : 'Booked'}">
          ${slot.time}
        </button>
      `).join('');
    }
  } catch (err) {
    container.innerHTML = '<div style="grid-column: 1/-1; color: var(--danger);">Failed to load time slots.</div>';
  }
}

// Select a time slot
function selectTimeSlot(time) {
  bookingState.time = time;
  document.querySelectorAll('.time-slot-btn').forEach(btn => btn.classList.remove('selected'));
  const clickedBtn = Array.from(document.querySelectorAll('.time-slot-btn')).find(b => b.innerText.trim() === time);
  if (clickedBtn) clickedBtn.classList.add('selected');
  updateSummaryCard();
}

// Update the Sticky Summary Box
function updateSummaryCard() {
  const sumService = document.getElementById('sum-service');
  const sumDuration = document.getElementById('sum-duration');
  const sumStylist = document.getElementById('sum-stylist');
  const sumDate = document.getElementById('sum-date');
  const sumTime = document.getElementById('sum-time');
  const sumTotal = document.getElementById('sum-total');

  if (sumService) sumService.innerText = bookingState.serviceName || 'None selected';
  if (sumDuration) sumDuration.innerText = bookingState.serviceDuration ? `${bookingState.serviceDuration} mins` : '-';
  if (sumStylist) sumStylist.innerText = bookingState.stylistName || 'Any Available';
  if (sumDate) sumDate.innerText = bookingState.date || 'Pick a date';
  if (sumTime) sumTime.innerText = bookingState.time || 'Pick a time';
  if (sumTotal) sumTotal.innerText = formatCurrency(bookingState.servicePrice);
}

// Stepper Navigation
function goToStep(step) {
  if (step === 2 && !bookingState.serviceId) {
    showToast('Please select a salon service first.', 'warning');
    return;
  }
  if (step === 4 && (!bookingState.date || !bookingState.time)) {
    showToast('Please pick both an appointment date and time slot.', 'warning');
    return;
  }

  currentStep = step;

  // Update step indicators
  for (let i = 1; i <= 4; i++) {
    const stepEl = document.getElementById(`stepper-${i}`);
    const cardEl = document.getElementById(`step-card-${i}`);
    if (stepEl) {
      stepEl.classList.remove('active', 'completed');
      if (i < currentStep) stepEl.classList.add('completed');
      if (i === currentStep) stepEl.classList.add('active');
    }
    if (cardEl) {
      cardEl.style.display = (i === currentStep) ? 'block' : 'none';
    }
  }

  window.scrollTo({ top: 120, behavior: 'smooth' });
}

// Submit Appointment Booking
async function submitBooking() {
  const user = getUser();
  const token = getToken();

  // If user is not logged in, redirect them to login with return state saved
  if (!user || !token) {
    sessionStorage.setItem('temp_booking_state', JSON.stringify(bookingState));
    showToast('Please log in to confirm your appointment booking.', 'info');
    setTimeout(() => {
      window.location.href = 'login.html?redirect=booking.html';
    }, 1200);
    return;
  }

  if (!bookingState.serviceId || !bookingState.date || !bookingState.time) {
    showToast('Please complete all booking selections.', 'error');
    return;
  }

  const notesInput = document.getElementById('customer-notes');
  const notes = notesInput ? notesInput.value.trim() : '';

  const confirmBtn = document.getElementById('confirm-booking-btn');
  if (confirmBtn) {
    confirmBtn.disabled = true;
    confirmBtn.innerText = 'Confirming Booking...';
  }

  try {
    const payload = {
      service_id: bookingState.serviceId,
      stylist_id: bookingState.stylistId === 'any' ? null : bookingState.stylistId,
      appointment_date: bookingState.date,
      appointment_time: bookingState.time,
      customer_notes: notes
    };

    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    const data = await res.json();

    if (res.ok && data.success) {
      // Show confirmation modal
      showBookingSuccessModal(data.appointment);
    } else {
      showToast(data.message || 'Booking failed. Slot might have just been taken.', 'error');
      if (confirmBtn) {
        confirmBtn.disabled = false;
        confirmBtn.innerText = 'Confirm & Book Appointment';
      }
    }
  } catch (err) {
    showToast('Server error during booking. Please try again.', 'error');
    if (confirmBtn) {
      confirmBtn.disabled = false;
      confirmBtn.innerText = 'Confirm & Book Appointment';
    }
  }
}

// Show success popup modal
function showBookingSuccessModal(appointment) {
  const modal = document.getElementById('booking-success-modal');
  if (!modal) return;

  document.getElementById('modal-booking-id').innerText = `#LX-${appointment.id}`;
  document.getElementById('modal-service-name').innerText = appointment.service_name;
  document.getElementById('modal-stylist-name').innerText = appointment.stylist_name || 'Assigned Salon Professional';
  document.getElementById('modal-date-time').innerText = `${appointment.appointment_date} at ${appointment.appointment_time}`;
  document.getElementById('modal-total-price').innerText = formatCurrency(appointment.total_price);

  modal.classList.add('open');
}

function closeSuccessModal() {
  const modal = document.getElementById('booking-success-modal');
  if (modal) modal.classList.remove('open');
  window.location.href = 'my-bookings.html';
}
