const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

// POST /api/contact - Submit contact inquiry
router.post('/', async (req, res) => {
  try {
    const { name, email, phone, subject, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and message are required.'
      });
    }

    await db.run(
      `INSERT INTO contact_messages (name, email, phone, subject, message)
       VALUES (?, ?, ?, ?, ?)`,
      [name.trim(), email.trim(), phone ? phone.trim() : null, subject ? subject.trim() : 'General Inquiry', message.trim()]
    );

    res.status(201).json({
      success: true,
      message: 'Thank you for reaching out! Our salon concierge will be in touch shortly.'
    });
  } catch (error) {
    console.error('Contact error:', error);
    res.status(500).json({ success: false, message: 'Failed to submit contact message.' });
  }
});

// GET /api/contact (Admin only - view messages)
router.get('/', requireAdmin, async (req, res) => {
  try {
    const messages = await db.all('SELECT * FROM contact_messages ORDER BY created_at DESC');
    res.json({ success: true, messages });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch messages.' });
  }
});

// GET /api/contact/reviews - Public reviews
router.get('/reviews', async (req, res) => {
  try {
    const reviews = await db.all('SELECT * FROM reviews ORDER BY rating DESC, created_at DESC LIMIT 6');
    res.json({ success: true, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch reviews.' });
  }
});

module.exports = router;
