const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

// GET /api/services/categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await db.all('SELECT * FROM categories ORDER BY id ASC');
    res.json({ success: true, categories });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch categories.' });
  }
});

// GET /api/services
router.get('/', async (req, res) => {
  try {
    const { category, search, popular } = req.query;
    let query = `
      SELECT s.*, c.name AS category_name, c.slug AS category_slug
      FROM services s
      LEFT JOIN categories c ON s.category_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (category && category !== 'all') {
      query += ` AND c.slug = ?`;
      params.push(category);
    }

    if (search) {
      query += ` AND (s.name LIKE ? OR s.description LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`);
    }

    if (popular === '1' || popular === 'true') {
      query += ` AND s.is_popular = 1`;
    }

    query += ` ORDER BY s.is_popular DESC, s.name ASC`;

    const services = await db.all(query, params);
    res.json({ success: true, services });
  } catch (error) {
    console.error('Error fetching services:', error);
    res.status(500).json({ success: false, message: 'Failed to load services.' });
  }
});

// GET /api/services/:id
router.get('/:id', async (req, res) => {
  try {
    const service = await db.get(
      `SELECT s.*, c.name AS category_name 
       FROM services s 
       LEFT JOIN categories c ON s.category_id = c.id 
       WHERE s.id = ?`,
      [req.params.id]
    );

    if (!service) {
      return res.status(404).json({ success: false, message: 'Service not found.' });
    }

    res.json({ success: true, service });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to load service details.' });
  }
});

// POST /api/services (Admin only)
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { name, category_id, description, duration, price, image_url, is_popular } = req.body;

    if (!name || !price || !duration) {
      return res.status(400).json({ success: false, message: 'Name, price, and duration are required.' });
    }

    const defaultImg = image_url || 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80';

    const result = await db.run(
      `INSERT INTO services (name, category_id, description, duration, price, image_url, is_popular)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [name.trim(), category_id || 1, description || '', parseInt(duration), parseFloat(price), defaultImg, is_popular ? 1 : 0]
    );

    res.status(201).json({
      success: true,
      message: 'Service created successfully!',
      serviceId: result.lastID
    });
  } catch (error) {
    console.error('Error creating service:', error);
    res.status(500).json({ success: false, message: 'Failed to create service.' });
  }
});

// PUT /api/services/:id (Admin only)
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const { name, category_id, description, duration, price, image_url, is_popular } = req.body;
    const { id } = req.params;

    const existing = await db.get('SELECT id FROM services WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Service not found.' });
    }

    await db.run(
      `UPDATE services 
       SET name = ?, category_id = ?, description = ?, duration = ?, price = ?, image_url = ?, is_popular = ?
       WHERE id = ?`,
      [name, category_id, description, parseInt(duration), parseFloat(price), image_url, is_popular ? 1 : 0, id]
    );

    res.json({ success: true, message: 'Service updated successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to update service.' });
  }
});

// DELETE /api/services/:id (Admin only)
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    await db.run('DELETE FROM services WHERE id = ?', [id]);
    res.json({ success: true, message: 'Service deleted successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to delete service.' });
  }
});

module.exports = router;
