# 🌸 LuxeGlow - Beauty Salon Appointment & Booking System

A full-stack, luxury beauty salon appointment and booking management web application featuring a modern responsive frontend, multi-page customer and administrative workflows, real-time availability scheduling, user authentication, and a persistent SQLite database.

---

## 📋 Features Overview

### 💎 Customer & Client Portal
- **Home Landing Page (`index.html`)**: Signature hero section, salon statistics, category showcase, client favorites, master stylists grid, verified testimonials, and salon operating hours.
- **Services & Pricing Menu (`services.html`)**: Filterable categories (Hair, Skin, Nails, Spa, Bridal), real-time search filtering, durations, prices, and one-click "Book This Service" integration.
- **Interactive 4-Step Booking Wizard (`booking.html`)**:
  - **Step 1: Choose Service**: Pre-selects service or lets client pick from the catalog.
  - **Step 2: Choose Specialist**: Select a specific master stylist or pick "First Available".
  - **Step 3: Real-Time Date & Time Slots**: Prevents double-booking by pulling live SQLite availability for morning, afternoon, and evening slots.
  - **Step 4: Review & Special Notes**: Add allergy warnings, bridal notes, or special preferences.
  - **Booking Confirmation Modal**: Displays appointment reference ID (`#LX-X`), duration, stylist, and total price.
- **User Authentication (`login.html` & `register.html`)**:
  - Secure bcrypt password hashing & JWT token sessions.
  - **1-Click Demo Login Buttons** for instant evaluation without manual typing.
- **Customer Dashboard (`my-bookings.html`)**:
  - Filter by All, Confirmed, Pending, Completed, or Cancelled appointments.
  - Cancel pending/confirmed appointments with one click.
- **About & Philosophy (`about.html`)**: Salon heritage, organic product philosophy, sterilization standards.
- **Concierge & Contact (`contact.html`)**: Working contact inquiry form that saves to the database, salon location, and operating hours.

### 👑 Administrative Management Portal (`admin.html`)
- **Protected Route**: Requires admin role token to access.
- **Real-Time KPI Dashboard**:
  - Total Revenue ($ calculation from confirmed & completed appointments)
  - Total Bookings count
  - Pending Bookings count
  - Total Registered Guests
- **Appointments Management**:
  - Search by guest name, email, service, or stylist.
  - Filter appointments by status (`pending`, `confirmed`, `completed`, `cancelled`).
  - Action buttons to **Confirm**, **Mark Completed**, **Cancel**, or **Delete** appointments in real time.
- **Salon Services Manager**:
  - View all services with category, duration, and pricing.
  - **Add New Service Modal**: Instantly create new salon treatments.
  - Delete obsolete services.
- **Specialists Manager**:
  - View master stylists, specialties, and ratings.
  - Remove staff members.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3 (Custom Luxury Design System, responsive flexbox & grid), Vanilla JavaScript (ES6+ Fetch API, DOM manipulation).
- **Backend**: Node.js, Express.js.
- **Database**: SQLite (via `sqlite3`, zero-configuration file database `salon.sqlite` with automatic schema creation and initial seeding).
- **Security & Authentication**: `bcryptjs` (password encryption), `jsonwebtoken` (JWT bearer authentication).

---

## 🔑 Demo Login Credentials

For testing and demonstration, the database comes pre-seeded with sample users:

| Role | Email | Password | Access Rights |
| :--- | :--- | :--- | :--- |
| **Customer** | `customer@gmail.com` | `customer123` | Book, view, and cancel personal appointments |
| **Administrator** | `admin@luxeglow.com` | `admin123` | Full access to Admin Dashboard, all bookings, service creator, and KPI analytics |

*(You can also use the **"Fill Customer"** or **"Fill Admin"** buttons on `login.html` for 1-click login!)*

---

## 🚀 How to Open and Execute in VS Code

### Step 1: Open the Project in VS Code
1. Open **Visual Studio Code**.
2. Go to **File** → **Open Folder...** (or press `Ctrl + K, Ctrl + O`).
3. Select this project folder:
   ```
   C:\Users\HP\.gemini\antigravity\scratch\beauty-salon-booking
   ```

### Step 2: Ensure Node.js is Installed
If you do not have Node.js installed on your machine:
- Download and install the **LTS version** from [https://nodejs.org/](https://nodejs.org/).
- Verify installation by opening the VS Code terminal and typing:
  ```bash
  node -v
  npm -v
  ```

### Step 3: Open Terminal in VS Code
1. In VS Code, open the integrated terminal:
   - Press **`Ctrl + \``** (backtick) or select **Terminal** → **New Terminal** from the top menu.
2. Confirm you are in the project root directory.

### Step 4: Install Dependencies
Run the following command in the terminal to install Express, SQLite3, and authentication libraries:
```bash
npm install
```

### Step 5: Start the Application
Run:
```bash
npm start
```
*You will see the console message:*
```
✨ LuxeGlow Beauty Salon Booking Portal Online ✨
Local URL: http://localhost:3000
Admin Portal: http://localhost:3000/admin.html
```

### Step 6: Open in Your Browser
- Visit: [http://localhost:3000](http://localhost:3000)
- Log in using either the Customer or Admin credentials to test all features.

*(Optional)* You can also simply double-click **`start.bat`** on Windows to automatically install dependencies and start the server in one click!

---

## 📁 Directory Structure

```
beauty-salon-booking/
├── .env                     # Server configuration (Port, JWT Secret)
├── config.js                # Configuration loader
├── package.json             # NPM package manifest
├── README.md                # Documentation & instructions
├── server.js                # Main Express server entry point
├── start.bat                # Windows 1-click startup batch script
├── database/
│   ├── db.js                # SQLite connection, tables, queries & auto-seed
│   └── salon.sqlite         # SQLite database file (created on launch)
├── middleware/
│   └── auth.js              # JWT authentication & admin authorization
├── routes/
│   ├── admin.js             # Admin analytics & KPI stats API
│   ├── appointments.js      # Appointments booking, availability & status API
│   ├── auth.js              # User registration & login API
│   ├── contact.js           # Inquiries & customer reviews API
│   ├── services.js          # Services & categories CRUD API
│   └── stylists.js          # Stylists & staff CRUD API
└── public/
    ├── index.html           # Salon homepage
    ├── services.html        # Services catalog & price list
    ├── booking.html         # 4-Step interactive booking wizard
    ├── login.html           # User login with 1-click demo helpers
    ├── register.html        # New customer sign-up
    ├── my-bookings.html     # Customer appointment management portal
    ├── admin.html           # Full administrative dashboard
    ├── about.html           # About salon & hygiene standards
    ├── contact.html         # Contact concierge & inquiry form
    ├── css/
    │   ├── style.css        # Core luxury design system & responsive styles
    │   ├── booking.css      # Stepper, time slot chips & summary card styles
    │   └── admin.css        # Admin sidebar, tables, cards & modal styles
    └── js/
        ├── main.js          # Global navbar, toasts & session management
        ├── auth.js          # Login & registration forms
        ├── services.js      # Services filter & search
        ├── booking.js       # Real-time slots & appointment submission
        ├── my-bookings.js   # Customer bookings view & cancellation
        └── admin.js         # Admin dashboard KPI & booking actions
```

---

## 📡 REST API Endpoints Reference

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Create new customer account
- `POST /api/auth/login` - Authenticate user & return JWT token
- `GET /api/auth/me` - Get current authenticated user profile

### Services (`/api/services`)
- `GET /api/services` - Get all services (query: `?category=slug&search=keyword&popular=1`)
- `GET /api/services/categories` - Get all service categories
- `GET /api/services/:id` - Get single service
- `POST /api/services` - *(Admin)* Create new service
- `DELETE /api/services/:id` - *(Admin)* Remove service

### Stylists (`/api/stylists`)
- `GET /api/stylists` - List all stylists
- `POST /api/stylists` - *(Admin)* Add new stylist
- `DELETE /api/stylists/:id` - *(Admin)* Remove stylist

### Appointments (`/api/appointments`)
- `GET /api/appointments/availability?date=YYYY-MM-DD&stylist_id=X` - Check free vs booked slots
- `POST /api/appointments` - Book appointment (prevents collision)
- `GET /api/appointments/my` - Get current logged-in customer's appointments
- `GET /api/appointments` - *(Admin)* View all appointments with filters
- `PUT /api/appointments/:id/cancel` - Cancel appointment
- `PUT /api/appointments/:id/status` - *(Admin)* Update status (`confirmed`, `completed`, `cancelled`)
- `DELETE /api/appointments/:id` - *(Admin)* Delete appointment record

### Admin Analytics (`/api/admin`)
- `GET /api/admin/stats` - Revenue, total counts, breakdown & recent bookings

### Contact & Reviews (`/api/contact`)
- `POST /api/contact` - Submit inquiry message
- `GET /api/contact/reviews` - Testimonials list
