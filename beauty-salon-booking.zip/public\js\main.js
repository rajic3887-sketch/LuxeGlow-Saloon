// LuxeGlow Beauty Salon - Main Client Utility Script

// Storage keys
const TOKEN_KEY = 'luxeglow_token';
const USER_KEY = 'luxeglow_user';

// Toast Notification Manager
function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = '✓';
  if (type === 'error') icon = '✕';
  if (type === 'warning') icon = '⚠';

  toast.innerHTML = `
    <div style="display: flex; align-items: center; gap: 10px;">
      <span style="font-weight: 700;">${icon}</span>
      <span>${message}</span>
    </div>
    <button style="background: none; border: none; font-size: 16px; cursor: pointer; color: inherit; opacity: 0.6;" onclick="this.parentElement.remove()">×</button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Authentication Helpers
function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function getUser() {
  const userStr = localStorage.getItem(USER_KEY);
  return userStr ? JSON.parse(userStr) : null;
}

function setAuthSession(token, user) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

function clearAuthSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

function logout() {
  clearAuthSession();
  showToast('You have been logged out.', 'info');
  setTimeout(() => {
    window.location.href = 'index.html';
  }, 500);
}

// Format Currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
}

// Update Navbar according to logged in state
function updateNavbar() {
  const navActions = document.getElementById('nav-actions');
  if (!navActions) return;

  const user = getUser();
  const token = getToken();

  if (user && token) {
    let adminLink = '';
    if (user.role === 'admin') {
      adminLink = `<a href="admin.html" class="btn btn-secondary btn-sm" style="border-color: #c58f5b;">Admin Portal</a>`;
    }

    navActions.innerHTML = `
      ${adminLink}
      <a href="my-bookings.html" class="nav-link" style="font-weight: 600;">My Appointments</a>
      <div style="display: flex; align-items: center; gap: 8px;">
        <span style="font-size: 14px; font-weight: 600; color: var(--dark);">${user.name.split(' ')[0]}</span>
        <button onclick="logout()" class="btn btn-dark btn-sm" style="padding: 6px 14px;">Logout</button>
      </div>
    `;
  } else {
    navActions.innerHTML = `
      <a href="login.html" class="nav-link" style="font-weight: 600;">Log In</a>
      <a href="booking.html" class="btn btn-primary btn-sm">Book Appointment</a>
    `;
  }
}

// Mobile Hamburger Toggle
document.addEventListener('DOMContentLoaded', () => {
  updateNavbar();

  const hamburger = document.getElementById('hamburger-btn');
  const navMenu = document.getElementById('nav-menu');
  if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  }
});
