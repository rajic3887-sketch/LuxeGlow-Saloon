// LuxeGlow Beauty Salon - Customer Appointments Portal

let myAppointments = [];
let currentFilter = 'all';

document.addEventListener('DOMContentLoaded', async () => {
  const user = getUser();
  const token = getToken();

  if (!user || !token) {
    showToast('Please log in to view your appointments.', 'info');
    setTimeout(() => {
      window.location.href = 'login.html?redirect=my-bookings.html';
    }, 1000);
    return;
  }

  // Set greeting
  const greeting = document.getElementById('user-greeting');
  if (greeting) {
    greeting.innerText = `Welcome back, ${user.name}!`;
  }

  await loadCustomerAppointments();
});

async function loadCustomerAppointments() {
  const container = document.getElementById('bookings-list');
  if (!container) return;

  container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-muted);">Loading your bookings...</div>';

  try {
    const token = getToken();
    const res = await fetch('/api/appointments/my', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();

    if (res.ok && data.success) {
      myAppointments = data.appointments;
      renderAppointments();
    } else {
      container.innerHTML = `<div style="text-align: center; color: var(--danger);">${data.message || 'Failed to load bookings.'}</div>`;
    }
  } catch (err) {
    container.innerHTML = '<div style="text-align: center; color: var(--danger);">Network error. Please try again.</div>';
  }
}

function filterBookings(status, activeBtn) {
  currentFilter = status;
  document.querySelectorAll('.booking-filter-btn').forEach(btn => {
    btn.classList.remove('btn-primary', 'active');
    btn.classList.add('btn-secondary');
  });

  if (activeBtn) {
    activeBtn.classList.add('btn-primary', 'active');
    activeBtn.classList.remove('btn-secondary');
  }

  renderAppointments();
}

function renderAppointments() {
  const container = document.getElementById('bookings-list');
  if (!container) return;

  let filtered = myAppointments;
  if (currentFilter !== 'all') {
    filtered = filtered.filter(a => a.status === currentFilter);
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="background: #fff; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 50px 20px; text-align: center;">
        <div style="font-size: 38px; margin-bottom: 12px;">📅</div>
        <h3 style="font-size: 20px; margin-bottom: 8px;">No ${currentFilter === 'all' ? '' : currentFilter} appointments found</h3>
        <p style="color: var(--text-muted); margin-bottom: 24px;">Ready to pamper yourself with luxury salon care?</p>
        <a href="booking.html" class="btn btn-primary">Book New Appointment</a>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(app => {
    const canCancel = (app.status === 'pending' || app.status === 'confirmed');

    return `
      <div style="background: #fff; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 24px; margin-bottom: 20px; box-shadow: var(--shadow-sm); display: flex; flex-direction: column; gap: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px;">
          <div>
            <span class="badge badge-${app.status}">${app.status}</span>
            <span style="font-size: 13px; color: var(--text-muted); margin-left: 8px;">Booking ID: #LX-${app.id}</span>
            <h3 style="font-size: 20px; margin-top: 6px;">${app.service_name}</h3>
          </div>
          <div style="font-size: 22px; font-weight: 700; color: var(--primary); font-family: 'Playfair Display', serif;">
            ${formatCurrency(app.total_price)}
          </div>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; background: var(--bg-cream); padding: 14px; border-radius: var(--radius-sm); font-size: 14px;">
          <div>
            <div style="color: var(--text-muted); font-size: 12px; text-transform: uppercase;">Date & Time</div>
            <strong>${app.appointment_date} at ${app.appointment_time}</strong>
          </div>
          <div>
            <div style="color: var(--text-muted); font-size: 12px; text-transform: uppercase;">Duration</div>
            <strong>${app.service_duration} Minutes</strong>
          </div>
          <div>
            <div style="color: var(--text-muted); font-size: 12px; text-transform: uppercase;">Specialist</div>
            <strong>${app.stylist_name || 'Assigned Salon Professional'}</strong>
          </div>
        </div>

        ${app.customer_notes ? `
          <div style="font-size: 13px; color: var(--text-muted); font-style: italic;">
            "Notes: ${app.customer_notes}"
          </div>
        ` : ''}

        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 10px; border-top: 1px solid var(--border-light);">
          <span style="font-size: 12px; color: var(--text-light);">Booked on ${new Date(app.created_at).toLocaleDateString()}</span>
          ${canCancel ? `
            <button onclick="cancelMyAppointment(${app.id})" class="btn btn-secondary btn-sm" style="color: var(--danger); border-color: #ffcdd2;">
              Cancel Appointment
            </button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

async function cancelMyAppointment(appointmentId) {
  if (!confirm('Are you sure you want to cancel this appointment?')) return;

  const token = getToken();
  try {
    const res = await fetch(`/api/appointments/${appointmentId}/cancel`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Appointment has been cancelled.', 'info');
      await loadCustomerAppointments();
    } else {
      showToast(data.message || 'Failed to cancel appointment.', 'error');
    }
  } catch (err) {
    showToast('Failed to connect to server.', 'error');
  }
}
