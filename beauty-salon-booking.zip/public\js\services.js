// LuxeGlow - Services Page Logic

let allServices = [];
let activeCategory = 'all';

document.addEventListener('DOMContentLoaded', async () => {
  await loadCategories();
  await loadServices();

  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      filterAndRenderServices(e.target.value.toLowerCase());
    });
  }
});

async function loadCategories() {
  const container = document.getElementById('category-filters');
  if (!container) return;

  try {
    const res = await fetch('/api/services/categories');
    const data = await res.json();

    if (data.success && data.categories) {
      data.categories.forEach(cat => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-secondary btn-sm filter-pill';
        btn.dataset.category = cat.slug;
        btn.innerText = cat.name;
        btn.onclick = () => selectCategory(cat.slug, btn);
        container.appendChild(btn);
      });
    }
  } catch (err) {
    console.error('Failed to load categories:', err);
  }
}

async function loadServices() {
  const grid = document.getElementById('services-grid');
  if (!grid) return;

  grid.innerHTML = '<div style="text-align: center; grid-column: 1/-1; padding: 40px; color: var(--text-muted);">Loading salon services...</div>';

  try {
    const res = await fetch('/api/services');
    const data = await res.json();

    if (data.success && data.services) {
      allServices = data.services;
      filterAndRenderServices();
    }
  } catch (err) {
    grid.innerHTML = '<div style="text-align: center; grid-column: 1/-1; color: var(--danger);">Failed to load salon services. Please refresh.</div>';
  }
}

function selectCategory(categorySlug, activeBtn) {
  activeCategory = categorySlug;
  document.querySelectorAll('.filter-pill').forEach(btn => btn.classList.remove('active', 'btn-primary'));
  if (activeBtn) {
    activeBtn.classList.add('active', 'btn-primary');
    activeBtn.classList.remove('btn-secondary');
  }
  const searchInput = document.getElementById('search-input');
  filterAndRenderServices(searchInput ? searchInput.value.toLowerCase() : '');
}

function filterAndRenderServices(searchTerm = '') {
  const grid = document.getElementById('services-grid');
  if (!grid) return;

  let filtered = allServices;

  if (activeCategory !== 'all') {
    filtered = filtered.filter(s => s.category_slug === activeCategory);
  }

  if (searchTerm.trim() !== '') {
    filtered = filtered.filter(s => 
      s.name.toLowerCase().includes(searchTerm) || 
      (s.description && s.description.toLowerCase().includes(searchTerm))
    );
  }

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div style="text-align: center; grid-column: 1/-1; padding: 60px 20px;">
        <h3 style="font-size: 20px; margin-bottom: 8px;">No salon services found</h3>
        <p style="color: var(--text-muted);">Try a different search keyword or category filter.</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = filtered.map(service => `
    <div class="service-card">
      <div class="service-card-img-wrap">
        <img src="${service.image_url}" alt="${service.name}" class="service-card-img" loading="lazy">
        ${service.is_popular ? '<span class="service-badge">★ Popular</span>' : ''}
      </div>
      <div class="service-card-body">
        <span class="service-category">${service.category_name || 'Salon Care'}</span>
        <h3 class="service-title">${service.name}</h3>
        <p class="service-desc">${service.description}</p>
        <div class="service-meta">
          <span class="service-duration">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            ${service.duration} mins
          </span>
          <span class="service-price">${formatCurrency(service.price)}</span>
        </div>
        <a href="booking.html?serviceId=${service.id}" class="btn btn-primary btn-sm btn-block">
          Book This Service
        </a>
      </div>
    </div>
  `).join('');
}
