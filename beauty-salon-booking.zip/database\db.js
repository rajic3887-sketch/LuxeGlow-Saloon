const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');
const config = require('../config');

// Open or create SQLite database file
const dbPath = config.DB_PATH;
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening SQLite database:', err.message);
  } else {
    console.log(`Connected to SQLite database at: ${dbPath}`);
  }
});

// Helper functions for Promise-based queries
const run = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
};

const get = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

const all = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
};

// Initialize Database Schema & Seed default data
const initDB = async () => {
  try {
    // Enable Foreign Keys
    await run('PRAGMA foreign_keys = ON');

    // 1. Users Table
    await run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        phone TEXT,
        role TEXT DEFAULT 'customer',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 2. Categories Table
    await run(`
      CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        icon TEXT
      )
    `);

    // 3. Stylists Table
    await run(`
      CREATE TABLE IF NOT EXISTS stylists (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        title TEXT NOT NULL,
        bio TEXT,
        specialties TEXT,
        rating REAL DEFAULT 4.9,
        image_url TEXT,
        is_active INTEGER DEFAULT 1
      )
    `);

    // 4. Services Table
    await run(`
      CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER,
        name TEXT NOT NULL,
        description TEXT,
        duration INTEGER NOT NULL,
        price REAL NOT NULL,
        image_url TEXT,
        is_popular INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE SET NULL
      )
    `);

    // 5. Appointments Table
    await run(`
      CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        service_id INTEGER NOT NULL,
        stylist_id INTEGER,
        appointment_date TEXT NOT NULL,
        appointment_time TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        total_price REAL NOT NULL,
        customer_notes TEXT,
        admin_notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (service_id) REFERENCES services (id) ON DELETE CASCADE,
        FOREIGN KEY (stylist_id) REFERENCES stylists (id) ON DELETE SET NULL
      )
    `);

    // 6. Contact Messages Table
    await run(`
      CREATE TABLE IF NOT EXISTS contact_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        subject TEXT,
        message TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 7. Reviews Table
    await run(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_name TEXT NOT NULL,
        service_name TEXT,
        rating INTEGER DEFAULT 5,
        comment TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Seed default data if users table is empty
    const userCount = await get('SELECT COUNT(*) as count FROM users');
    if (userCount.count === 0) {
      console.log('Seeding initial data into SQLite database...');
      await seedDatabase();
    }
  } catch (error) {
    console.error('Error initializing database tables:', error);
  }
};

const seedDatabase = async () => {
  // Password hash for 'admin123' and 'customer123'
  const salt = await bcrypt.genSalt(10);
  const adminPassword = await bcrypt.hash('admin123', salt);
  const customerPassword = await bcrypt.hash('customer123', salt);

  // 1. Insert default admin & demo customer
  await run(
    `INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)`,
    ['LuxeGlow Admin', 'admin@luxeglow.com', adminPassword, '+1 (555) 019-2834', 'admin']
  );

  const customerRes = await run(
    `INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)`,
    ['Sophia Reynolds', 'customer@gmail.com', customerPassword, '+1 (555) 438-9210', 'customer']
  );
  const customerId = customerRes.lastID;

  // 2. Insert Categories
  const categories = [
    { name: 'Hair & Styling', slug: 'hair', description: 'Precision cuts, balayage, keratin treatments & blowout', icon: 'scissors' },
    { name: 'Skin & Facials', slug: 'skin', description: 'Rejuvenating hydrafacials, anti-aging therapies & peels', icon: 'sparkles' },
    { name: 'Nails & Lashes', slug: 'nails', description: 'Russian manicure, luxury gel overlays & lash extensions', icon: 'hand' },
    { name: 'Massage & Spa', slug: 'spa', description: 'Deep tissue therapy, hot stone & aromatherapy relaxation', icon: 'heart' },
    { name: 'Bridal & Glam', slug: 'bridal', description: 'Couture bridal styling, airbrush makeup & complete packages', icon: 'star' }
  ];

  for (const cat of categories) {
    await run(
      `INSERT INTO categories (name, slug, description, icon) VALUES (?, ?, ?, ?)`,
      [cat.name, cat.slug, cat.description, cat.icon]
    );
  }

  // 3. Insert Stylists
  const stylists = [
    {
      name: 'Elena Rostova',
      title: 'Artistic Hair Director',
      bio: 'Over 12 years of runway and editorial styling experience in Paris and New York. Master of balayage and structural precision cutting.',
      specialties: 'Balayage, Precision Cuts, Keratin Smoothing',
      rating: 4.95,
      image_url: 'https://images.unsplash.com/photo-1595956553066-fe24a8c33395?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Camila Vance',
      title: 'Senior Medical Esthetician',
      bio: 'Certified clinical skincare specialist focusing on holistic dermal rejuvenation, micro-needling, and deep hydration therapies.',
      specialties: 'HydraFacials, Dermaplaning, Chemical Peels',
      rating: 4.98,
      image_url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Marcus Sterling',
      title: 'Master Colorist & Blowout Specialist',
      bio: 'Vidal Sassoon trained with an intuitive eye for luminous dimension, vivid shades, and red-carpet blowout styling.',
      specialties: 'Highlights, Color Correction, Silk Press',
      rating: 4.92,
      image_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80'
    },
    {
      name: 'Aria Chen',
      title: 'Nail Artist & Lash Couturier',
      bio: 'Renowned for intricate Japanese gel art, sculptured nail extensions, and bespoke Russian volume lash sets.',
      specialties: 'Russian Manicure, Nail Sculpting, Volume Lashes',
      rating: 4.97,
      image_url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80'
    }
  ];

  for (const s of stylists) {
    await run(
      `INSERT INTO stylists (name, title, bio, specialties, rating, image_url) VALUES (?, ?, ?, ?, ?, ?)`,
      [s.name, s.title, s.bio, s.specialties, s.rating, s.image_url]
    );
  }

  // 4. Insert Services
  const services = [
    {
      category_id: 1,
      name: 'Signature Luxe Haircut & Blowout',
      description: 'Consultation, scalp massage with organic botanical oils, custom precision haircut, and bouncy salon blowout.',
      duration: 60,
      price: 85.00,
      image_url: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80',
      is_popular: 1
    },
    {
      category_id: 1,
      name: 'Full Custom Balayage & Gloss',
      description: 'Hand-painted dimensional highlighting with bond-building treatment and gloss tone for radiant, seamless color.',
      duration: 150,
      price: 240.00,
      image_url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80',
      is_popular: 1
    },
    {
      category_id: 1,
      name: 'Brazilian Keratin Smoothing Infusion',
      description: 'Intense smoothing formula eliminating 95% of frizz while restoring luster and silky softness for up to 4 months.',
      duration: 120,
      price: 195.00,
      image_url: 'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=600&q=80',
      is_popular: 0
    },
    {
      category_id: 2,
      name: 'Diamond Glow HydraFacial',
      description: 'Patented 3-in-1 technology deeply cleanses, extracts, and hydrates the skin with concentrated peptide serums.',
      duration: 60,
      price: 165.00,
      image_url: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=600&q=80',
      is_popular: 1
    },
    {
      category_id: 2,
      name: '24K Gold Rejuvenation Facial',
      description: 'Cellular renewal treatment using genuine 24k gold leaf foil, collagen peptide masks, and lymphatic drainage.',
      duration: 75,
      price: 180.00,
      image_url: 'https://images.unsplash.com/photo-1512290900672-1f48651f5fd6?auto=format&fit=crop&w=600&q=80',
      is_popular: 0
    },
    {
      category_id: 3,
      name: 'Luxe Russian Manicure & Gel Art',
      description: 'Dry cuticle clean-up technique for flawless durability, builder gel strengthening overlay, and custom nail art.',
      duration: 90,
      price: 95.00,
      image_url: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&w=600&q=80',
      is_popular: 1
    },
    {
      category_id: 3,
      name: 'Velvet Pedicure & Paraffin Bath',
      description: 'Exfoliating sugar scrub, hot towel compress, warm nourishing paraffin dip, cuticle detailing, and polish.',
      duration: 60,
      price: 75.00,
      image_url: 'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?auto=format&fit=crop&w=600&q=80',
      is_popular: 0
    },
    {
      category_id: 4,
      name: 'Deep Tissue Aromatherapy Massage',
      description: 'Therapeutic pressure targeting muscle tension, paired with lavender and eucalyptus essential oils.',
      duration: 60,
      price: 110.00,
      image_url: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&w=600&q=80',
      is_popular: 1
    },
    {
      category_id: 5,
      name: 'Bridal Glam Couture Package',
      description: 'Complete trial and wedding day styling: HD airbrush makeup, couture hair updo, veil setting, and mink lashes.',
      duration: 180,
      price: 380.00,
      image_url: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=600&q=80',
      is_popular: 1
    }
  ];

  for (const s of services) {
    await run(
      `INSERT INTO services (category_id, name, description, duration, price, image_url, is_popular) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [s.category_id, s.name, s.description, s.duration, s.price, s.image_url, s.is_popular]
    );
  }

  // 5. Insert Sample Appointments for Sophia Reynolds
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  const nextWeek = new Date();
  nextWeek.setDate(nextWeek.getDate() + 7);
  const nextWeekStr = nextWeek.toISOString().split('T')[0];

  const pastDate = new Date();
  pastDate.setDate(pastDate.getDate() - 5);
  const pastDateStr = pastDate.toISOString().split('T')[0];

  await run(
    `INSERT INTO appointments (user_id, service_id, stylist_id, appointment_date, appointment_time, status, total_price, customer_notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [customerId, 1, 1, tomorrowStr, '10:00 AM', 'confirmed', 85.00, 'Looking forward to a fresh layered cut!']
  );

  await run(
    `INSERT INTO appointments (user_id, service_id, stylist_id, appointment_date, appointment_time, status, total_price, customer_notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [customerId, 4, 2, nextWeekStr, '02:30 PM', 'pending', 165.00, 'Sensitive skin, please use gentle peptide serum.']
  );

  await run(
    `INSERT INTO appointments (user_id, service_id, stylist_id, appointment_date, appointment_time, status, total_price, customer_notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [customerId, 6, 4, pastDateStr, '11:00 AM', 'completed', 95.00, 'Loved the french tip design!']
  );

  // 6. Insert Reviews
  const reviews = [
    {
      customer_name: 'Sophia Reynolds',
      service_name: 'Luxe Russian Manicure',
      rating: 5,
      comment: 'Aria is absolute perfection! The Russian manicure lasts over 4 weeks without a single chip. The salon ambience is so tranquil.'
    },
    {
      customer_name: 'Jessica Miller',
      service_name: 'Full Custom Balayage',
      rating: 5,
      comment: 'Elena transformed my dull brunette hair into sun-kissed perfection. Truly the premier beauty salon experience!'
    },
    {
      customer_name: 'Emily Davis',
      service_name: 'Diamond Glow HydraFacial',
      rating: 5,
      comment: 'My skin has never felt this plump and glowing. Camila gives the best skincare consultations and facial massages.'
    }
  ];

  for (const r of reviews) {
    await run(
      `INSERT INTO reviews (customer_name, service_name, rating, comment) VALUES (?, ?, ?, ?)`,
      [r.customer_name, r.service_name, r.rating, r.comment]
    );
  }

  console.log('Database seeded successfully with default users, services, stylists, and sample bookings.');
};

module.exports = {
  db,
  run,
  get,
  all,
  initDB
};
