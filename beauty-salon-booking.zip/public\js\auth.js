// LuxeGlow Beauty Salon - Authentication Handler

document.addEventListener('DOMContentLoaded', () => {
  // Check if user is already logged in
  const user = getUser();
  const token = getToken();

  // If already logged in and visiting login.html, redirect
  if (user && token && (window.location.pathname.endsWith('login.html') || window.location.pathname.endsWith('register.html'))) {
    if (user.role === 'admin') {
      window.location.href = 'admin.html';
    } else {
      window.location.href = 'my-bookings.html';
    }
    return;
  }

  // Handle Login Form
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerText;
      submitBtn.innerText = 'Signing in...';
      submitBtn.disabled = true;

      const email = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;

      try {
        const response = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok && data.success) {
          setAuthSession(data.token, data.user);
          showToast(`Welcome back, ${data.user.name}!`, 'success');

          setTimeout(() => {
            // Check if there was a redirect query param
            const params = new URLSearchParams(window.location.search);
            const redirect = params.get('redirect');

            if (redirect) {
              window.location.href = redirect;
            } else if (data.user.role === 'admin') {
              window.location.href = 'admin.html';
            } else {
              window.location.href = 'my-bookings.html';
            }
          }, 800);
        } else {
          showToast(data.message || 'Login failed. Please check your credentials.', 'error');
          submitBtn.innerText = originalText;
          submitBtn.disabled = false;
        }
      } catch (err) {
        showToast('Server communication error. Please try again.', 'error');
        submitBtn.innerText = originalText;
        submitBtn.disabled = false;
      }
    });
  }

  // Handle Registration Form
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerText;

      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const phone = document.getElementById('phone').value.trim();
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirm-password').value;

      if (password !== confirmPassword) {
        showToast('Passwords do not match.', 'error');
        return;
      }

      if (password.length < 6) {
        showToast('Password must be at least 6 characters.', 'error');
        return;
      }

      submitBtn.innerText = 'Creating Account...';
      submitBtn.disabled = true;

      try {
        const response = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, phone, password })
        });

        const data = await response.json();

        if (response.ok && data.success) {
          setAuthSession(data.token, data.user);
          showToast('Account created successfully! Welcome to LuxeGlow.', 'success');

          setTimeout(() => {
            window.location.href = 'booking.html';
          }, 1000);
        } else {
          showToast(data.message || 'Registration failed.', 'error');
          submitBtn.innerText = originalText;
          submitBtn.disabled = false;
        }
      } catch (err) {
        showToast('Connection error. Please try again.', 'error');
        submitBtn.innerText = originalText;
        submitBtn.disabled = false;
      }
    });
  }
});

// Demo login fill helpers
function fillDemo(role) {
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');

  if (!emailInput || !passwordInput) return;

  if (role === 'admin') {
    emailInput.value = 'admin@luxeglow.com';
    passwordInput.value = 'admin123';
    showToast('Admin credentials filled!', 'info');
  } else {
    emailInput.value = 'customer@gmail.com';
    passwordInput.value = 'customer123';
    showToast('Customer credentials filled!', 'info');
  }
}
