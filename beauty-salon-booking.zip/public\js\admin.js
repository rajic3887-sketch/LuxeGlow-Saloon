// LuxeGlow Beauty Salon - Admin Management Controller

let adminAppointments = [];
let adminServices = [];
let adminStylists = [];

document.addEventListener('DOMContentLoaded', async () => {
  const user = getUser();
  const token = getToken();

  if (!user || !token || user.role !== 'admin') {
    showToast('Unauthorized access. Admin privileges required.', 'error');
    setTimeout(() => {
      window.location.href = 'login.html';
    }, 1000);
    return;
  }

  // Set admin name in sidebar
  const adminName = document.getElementById('admin-display-name');
  if (adminName) adminName.innerText = user.name;

  // Initial loads
  await loadAdminStats();
  await loadAdminAppointments();
  await loadAdminServices();
  await loadAdminStylists();

  // Filter input listeners
  const searchInput = document.getElementById('admin-search');
  const statusFilter = document.getElementById('admin-status-filter');

  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (statusFilter) statusFilter.addEventListener('change', applyFilters);
});

// Switch Sidebar Tabs
function switchAdminTab(tabName) {
  document.querySelectorAll('.admin-nav-item').forEach(el => el.classList.remove('active'));
  const activeNavItem = document.getElementById(`nav-tab-${tabName}`);
  if (activeNavItem) activeNavItem.classList.add('active');

  const tabs = ['dashboard', 'appointments', 'services', 'stylists'];
  tabs.forEach(t => {
    const el = document.getElementById(`view-${t}`);
    if (el) el.style.display = (t === tabName) ? 'block' : 'none';
  });
}

// 1. Load Stats & KPI Cards
async function loadAdminStats() {
  const token = getToken();
  try {
    const res = await fetch('/api/admin/stats', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();

    if (res.ok && data.success && data.stats) {
      const s = data.stats;
      document.getElementById('kpi-revenue').innerText = formatCurrency(s.totalRevenue || 0);
      document.getElementById('kpi-bookings').innerText = s.totalBookings || 0;
      document.getElementById('kpi-pending').innerText = s.pendingBookings || 0;
      document.getElementById('kpi-customers').innerText = s.totalCustomers || 0;
    }
  } catch (err) {
    console.error('Error loading admin stats:', err);
  }
}

// 2. Load Appointments
async function loadAdminAppointments() {
  const token = getToken();
  const tbody = document.getElementById('admin-appointments-tbody');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 30px;">Loading appointments...</td></tr>';

  try {
    const res = await fetch('/api/appointments', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();

    if (res.ok && data.success) {
      adminAppointments = data.appointments;
      renderAdminAppointmentsTable(adminAppointments);
    }
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: var(--danger); padding: 30px;">Failed to load appointments.</td></tr>';
  }
}

function applyFilters() {
  const search = document.getElementById('admin-search')?.value.toLowerCase() || '';
  const status = document.getElementById('admin-status-filter')?.value || 'all';

  let filtered = adminAppointments;

  if (status !== 'all') {
    filtered = filtered.filter(a => a.status === status);
  }

  if (search.trim() !== '') {
    filtered = filtered.filter(a => 
      a.customer_name.toLowerCase().includes(search) ||
      a.customer_email.toLowerCase().includes(search) ||
      a.service_name.toLowerCase().includes(search) ||
      (a.stylist_name && a.stylist_name.toLowerCase().includes(search))
    );
  }

  renderAdminAppointmentsTable(filtered);
}

function renderAdminAppointmentsTable(appointments) {
  const tbody = document.getElementById('admin-appointments-tbody');
  if (!tbody) return;

  if (appointments.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">No matching appointments found.</td></tr>';
    return;
  }

  tbody.innerHTML = appointments.map(a => `
    <tr>
      <td><strong>#LX-${a.id}</strong></td>
      <td>
        <div><strong>${a.customer_name}</strong></div>
        <div style="font-size: 12px; color: var(--text-muted);">${a.customer_email}</div>
        ${a.customer_phone ? `<div style="font-size: 11px; color: var(--text-light);">${a.customer_phone}</div>` : ''}
      </td>
      <td>
        <strong>${a.service_name}</strong>
        <div style="font-size: 12px; color: var(--text-muted);">Stylist: ${a.stylist_name || 'Any'}</div>
      </td>
      <td>
        <div>${a.appointment_date}</div>
        <div style="font-weight: 600; font-size: 13px; color: var(--primary);">${a.appointment_time}</div>
      </td>
      <td><strong>${formatCurrency(a.total_price)}</strong></td>
      <td><span class="badge badge-${a.status}">${a.status}</span></td>
      <td>
        <div class="table-actions">
          ${a.status === 'pending' ? `
            <button onclick="updateAppointmentStatus(${a.id}, 'confirmed')" class="action-btn confirm" title="Confirm Booking">✓ Confirm</button>
          ` : ''}
          ${a.status === 'confirmed' ? `
            <button onclick="updateAppointmentStatus(${a.id}, 'completed')" class="action-btn complete" title="Mark Completed">★ Complete</button>
          ` : ''}
          ${a.status !== 'cancelled' && a.status !== 'completed' ? `
            <button onclick="updateAppointmentStatus(${a.id}, 'cancelled')" class="action-btn cancel" title="Cancel Booking">✕ Cancel</button>
          ` : ''}
          <button onclick="deleteAppointment(${a.id})" class="action-btn delete" title="Delete Record">🗑</button>
        </div>
      </td>
    </tr>
  `).join('');
}

// Update Appointment Status
async function updateAppointmentStatus(id, newStatus) {
  const token = getToken();
  try {
    const res = await fetch(`/api/appointments/${id}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ status: newStatus })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast(`Booking #LX-${id} updated to ${newStatus}.`, 'success');
      await loadAdminAppointments();
      await loadAdminStats();
    } else {
      showToast(data.message || 'Status update failed.', 'error');
    }
  } catch (err) {
    showToast('Failed to connect to server.', 'error');
  }
}

// Delete Appointment
async function deleteAppointment(id) {
  if (!confirm(`Are you sure you want to permanently delete appointment #LX-${id}?`)) return;

  const token = getToken();
  try {
    const res = await fetch(`/api/appointments/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast(`Appointment #LX-${id} deleted.`, 'info');
      await loadAdminAppointments();
      await loadAdminStats();
    }
  } catch (err) {
    showToast('Delete error.', 'error');
  }
}

// 3. Load Admin Services List
async function loadAdminServices() {
  const container = document.getElementById('admin-services-table-body');
  if (!container) return;

  try {
    const res = await fetch('/api/services');
    const data = await res.json();

    if (data.success && data.services) {
      adminServices = data.services;
      container.innerHTML = adminServices.map(s => `
        <tr>
          <td><img src="${s.image_url}" style="width: 50px; height: 50px; object-fit: cover; border-radius: 8px;"></td>
          <td>
            <strong>${s.name}</strong>
            <div style="font-size: 12px; color: var(--text-muted);">${s.description ? s.description.substring(0, 60) + '...' : ''}</div>
          </td>
          <td>${s.category_name || 'Salon'}</td>
          <td>${s.duration} mins</td>
          <td><strong>${formatCurrency(s.price)}</strong></td>
          <td>${s.is_popular ? '★ Yes' : 'No'}</td>
          <td>
            <button onclick="deleteService(${s.id})" class="action-btn delete">Delete</button>
          </td>
        </tr>
      `).join('');
    }
  } catch (err) {
    console.error('Failed to load admin services:', err);
  }
}

// Open Add Service Modal
function openAddServiceModal() {
  const modal = document.getElementById('add-service-modal');
  if (modal) modal.classList.add('open');
}

function closeAddServiceModal() {
  const modal = document.getElementById('add-service-modal');
  if (modal) modal.classList.remove('open');
}

// Create New Service
async function handleCreateService(e) {
  e.preventDefault();
  const token = getToken();

  const name = document.getElementById('new-service-name').value;
  const category_id = document.getElementById('new-service-category').value;
  const price = document.getElementById('new-service-price').value;
  const duration = document.getElementById('new-service-duration').value;
  const description = document.getElementById('new-service-desc').value;
  const image_url = document.getElementById('new-service-img').value;

  try {
    const res = await fetch('/api/services', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ name, category_id, price, duration, description, image_url })
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('New service added successfully!', 'success');
      closeAddServiceModal();
      document.getElementById('add-service-form').reset();
      await loadAdminServices();
    } else {
      showToast(data.message || 'Failed to add service.', 'error');
    }
  } catch (err) {
    showToast('Failed to add service.', 'error');
  }
}

// Delete Service
async function deleteService(id) {
  if (!confirm('Are you sure you want to delete this service?')) return;
  const token = getToken();

  try {
    const res = await fetch(`/api/services/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Service deleted.', 'info');
      await loadAdminServices();
    }
  } catch (err) {
    showToast('Failed to delete service.', 'error');
  }
}

// 4. Load Admin Stylists List
async function loadAdminStylists() {
  const container = document.getElementById('admin-stylists-grid');
  if (!container) return;

  try {
    const res = await fetch('/api/stylists');
    const data = await res.json();

    if (data.success && data.stylists) {
      adminStylists = data.stylists;
      container.innerHTML = adminStylists.map(st => `
        <div style="background: #fff; border: 1px solid var(--border-light); border-radius: var(--radius-md); padding: 18px; display: flex; gap: 14px; align-items: center;">
          <img src="${st.image_url}" style="width: 60px; height: 60px; border-radius: 50%; object-fit: cover;">
          <div style="flex-grow: 1;">
            <div style="font-weight: 700; font-size: 16px;">${st.name}</div>
            <div style="color: var(--primary); font-size: 13px;">${st.title}</div>
            <div style="font-size: 12px; color: var(--text-muted);">Rating: ★ ${st.rating}</div>
          </div>
          <button onclick="deleteStylist(${st.id})" class="action-btn delete">Remove</button>
        </div>
      `).join('');
    }
  } catch (err) {
    console.error('Failed to load admin stylists:', err);
  }
}

// Delete Stylist
async function deleteStylist(id) {
  if (!confirm('Are you sure you want to remove this specialist?')) return;
  const token = getToken();

  try {
    const res = await fetch(`/api/stylists/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });

    const data = await res.json();
    if (res.ok && data.success) {
      showToast('Stylist removed.', 'info');
      await loadAdminStylists();
    }
  } catch (err) {
    showToast('Failed to delete stylist.', 'error');
  }
}
