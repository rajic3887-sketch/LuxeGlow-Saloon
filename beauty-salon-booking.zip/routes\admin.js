const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

// GET /api/admin/stats
router.get('/stats', requireAdmin, async (req, res) => {
  try {
    // 1. Total Appointments
    const totalBookingsRow = await db.get('SELECT COUNT(*) AS total FROM appointments');
    const totalBookings = totalBookingsRow.total || 0;

    // 2. Total Revenue (sum of completed & confirmed)
    const revenueRow = await db.get(
      `SELECT SUM(total_price) AS revenue FROM appointments WHERE status IN ('completed', 'confirmed')`
    );
    const totalRevenue = revenueRow.revenue || 0;

    // 3. Status breakdown
    const pendingRow = await db.get(`SELECT COUNT(*) AS count FROM appointments WHERE status = 'pending'`);
    const confirmedRow = await db.get(`SELECT COUNT(*) AS count FROM appointments WHERE status = 'confirmed'`);
    const completedRow = await db.get(`SELECT COUNT(*) AS count FROM appointments WHERE status = 'completed'`);
    const cancelledRow = await db.get(`SELECT COUNT(*) AS count FROM appointments WHERE status = 'cancelled'`);

    // 4. Total Customers
    const customersRow = await db.get(`SELECT COUNT(*) AS count FROM users WHERE role = 'customer'`);
    const totalCustomers = customersRow.count || 0;

    // 5. Total Stylists
    const stylistsRow = await db.get(`SELECT COUNT(*) AS count FROM stylists WHERE is_active = 1`);
    const totalStylists = stylistsRow.count || 0;

    // 6. Recent 5 Bookings
    const recentBookings = await db.all(
      `SELECT a.id, a.appointment_date, a.appointment_time, a.status, a.total_price,
              s.name AS service_name,
              u.name AS customer_name,
              st.name AS stylist_name
       FROM appointments a
       JOIN services s ON a.service_id = s.id
       JOIN users u ON a.user_id = u.id
       LEFT JOIN stylists st ON a.stylist_id = st.id
       ORDER BY a.created_at DESC
       LIMIT 5`
    );

    // 7. Top booked services
    const topServices = await db.all(
      `SELECT s.name, COUNT(a.id) AS booking_count, SUM(a.total_price) AS total_sales
       FROM appointments a
       JOIN services s ON a.service_id = s.id
       WHERE a.status != 'cancelled'
       GROUP BY s.id
       ORDER BY booking_count DESC
       LIMIT 4`
    );

    res.json({
      success: true,
      stats: {
        totalBookings,
        totalRevenue,
        pendingBookings: pendingRow.count || 0,
        confirmedBookings: confirmedRow.count || 0,
        completedBookings: completedRow.count || 0,
        cancelledBookings: cancelledRow.count || 0,
        totalCustomers,
        totalStylists,
        recentBookings,
        topServices
      }
    });
  } catch (error) {
    console.error('Admin stats error:', error);
    res.status(500).json({ success: false, message: 'Failed to compute salon statistics.' });
  }
});

module.exports = router;
