const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { requireAdmin } = require('../middleware/auth');

// GET /api/stylists
router.get('/', async (req, res) => {
  try {
    const stylists = await db.all('SELECT * FROM stylists WHERE is_active = 1 ORDER BY rating DESC, name ASC');
    res.json({ success: true, stylists });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch stylists.' });
  }
});

// GET /api/stylists/:id
router.get('/:id', async (req, res) => {
  try {
    const stylist = await db.get('SELECT * FROM stylists WHERE id = ?', [req.params.id]);
    if (!stylist) {
      return res.status(404).json({ success: false, message: 'Stylist not found.' });
    }
    res.json({ success: true, stylist });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to fetch stylist.' });
  }
});

// POST /api/stylists (Admin only)
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { name, title, bio, specialties, rating, image_url } = req.body;
    if (!name || !title) {
      return res.status(400).json({ success: false, message: 'Name and title are required.' });
    }

    const defaultImg = image_url || 'https://images.unsplash.com/photo-1595956553066-fe24a8c33395?auto=format&fit=crop&w=600&q=80';

    const result = await db.run(
      `INSERT INTO stylists (name, title, bio, specialties, rating, image_url, is_active)
       VALUES (?, ?, ?, ?, ?, ?, 1)`,
      [name, title, bio || '', specialties || '', rating ? parseFloat(rating) : 4.9, defaultImg]
    );

    res.status(201).json({ success: true, message: 'Stylist added successfully!', stylistId: result.lastID });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to add stylist.' });
  }
});

// DELETE /api/stylists/:id (Admin only)
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await db.run('DELETE FROM stylists WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Stylist removed successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to remove stylist.' });
  }
});

module.exports = router;
